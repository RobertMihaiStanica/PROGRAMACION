Muchos de las funcionaldiades del progrma no estan pulidas del todo. Estoy experimentando con los menus y la manera mas efectiva de generarlos y tambien como hacer que devuelvan los valores deseados de una manera sencilla y modular.

Me he centrado en un principio mas en la "interfaz de usuario" y unos menus claros que en los demas aspectos del programa los cuales ire desarollando a lo largo de estas vacaciones. 

Por ahora entrego el programa tal y como esta esperando tener la version completa a la vuelta en Enero. 

El .exe se encuentra en .\ConsolePokemon\bin\Debug\net6.0